import React from 'react'
import AdminFoodItems from './AdminFoodItems'

const AdminFoodItemsOutlet = () => {
  return (
    <>
       <AdminFoodItems/>
    </>
  )
}

export default AdminFoodItemsOutlet