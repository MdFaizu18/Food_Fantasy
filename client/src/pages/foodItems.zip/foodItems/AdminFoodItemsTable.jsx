import { Box, InputBase, TextField, Typography } from "@mui/material";
import React from "react";
import AdminNavbar from "../../components/AdminNavbar"
import { WrapperAdminResponiveBox } from "../../assets/wrapper/AdminResponsiveWrapper";
import ReorderIcon from "@mui/icons-material/Reorder";
import SearchIcon from "@mui/icons-material/Search";
import styled from "styled-components";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import EditIcon from "@mui/icons-material/Edit";


function createData(preview, dishName, category, price, quantity, createdBy,status, actions) {
    return { preview, dishName, category, price, quantity, createdBy,status, actions };
}
const rows = [
    createData("img", "Frozen yoghurt", 159, "Code", 6.0, 2, 24, 4.0),
    createData("img", "Ice cream sandwich", 237, "Pain", 9.0, 3, 37, 4.3),
    createData("img", "Eclair", 262, "Deepak", 16.0, 24, 5, 6.0),
    createData("img", "Cupcake", 305, "Harley ", 3.7, 67, 7, 4.3),
    createData("img", "Gingerbread", 356, "priya", 16.0, 49, 8, 3.9),
    createData("img", "Gingerbread", 356, "priya", 16.0, 49, 8, 3.9),
    createData("img", "Gingerbread", 356, "priya", 16.0, 49, 8, 3.9),
    createData("img", "Gingerbread", 356, "priya", 16.0, 49, 8, 3.9),
    createData("img", "Gingerbread", 356, "priya", 16.0, 49, 8, 3.9),
];
const Headers = [
    { id: 1, name: "Preview" },
    { id: 2, name: "Dish Name" },
    { id: 3, name: "Category" },
    { id: 4, name: "Price" },
    { id: 5, name: "Quantity" },
    { id: 6, name: "Created By" },
    { id: 7, name: "Status" },
    { id: 8, name: "Actions" },
];
const AdminFoodItemsTable = () => {
    return (
        <>
           
                {/* //*-------------Reservation details------------------- */}
            <Box sx={{ paddingBottom: '5%' }} >
                    <TableContainer component={Paper} sx={{ width: "1250px" }}>
                        <Table sx={{ Width: "850px" }} aria-label="simple table">
                       
                            <TableHead>
                                <TableRow>
                                    {Headers.map((title) => (
                                        <TableCell
                                            align="center"
                                            sx={{ fontSize: "18px", fontWeight: "600", color:'rgb(255, 167, 50)' }}
                                            key={title.id}
                                        >
                                            {title.name}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {rows.map((row) => (
                                    <TableRow
                                        // key={row.status}
                                        sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                                    >
                                        <TableCell component="th" scope="row" align="center">
                                            {row.preview}
                                        </TableCell>
                                        <TableCell align="center">{row.dishName}</TableCell>
                                        <TableCell align="center">{row.category}</TableCell>
                                        <TableCell align="center">{row.price}</TableCell>
                                        <TableCell align="center">{row.quantity}</TableCell>
                                        <TableCell align="center">{row.createdBy}</TableCell>
                                        <TableCell align="center">{row.status}</TableCell>
                                        <TableCell align="center">
                                            <EditIcon color="primary" />
                                            <DeleteForeverIcon color="error" />
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Box>
          
        </>
    );
};

export default AdminFoodItemsTable;