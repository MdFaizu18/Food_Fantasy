import { Box, Button, Stack, TextField, Typography, styled } from '@mui/material';
import { AddDishesLeftWrapper, AddDishesMainWrapper, AddDishesRightInnerBox, AddDishesRightWrapper, PreviewInnerBox } from '../../assets/wrapper/AddDishesWrappper';
import React, { useState } from 'react';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';  
import AddDishesForm from './AddDishesForm';




const AddDishesBox = () => {
    const [selectedFile, setSelectedFile] = useState(null);
    const [previewUrl, setPreviewUrl] = useState(null);

    // Function to handle file selection
    const handleFileChange = (event) => {
        const file = event.target.files[0];
        setSelectedFile(file);

        // Generate a preview URL for the selected image
        const reader = new FileReader();
        reader.onload = () => {
            setPreviewUrl(reader.result);
        };
        reader.readAsDataURL(file);
    };
    return (
        <AddDishesMainWrapper>
           <AddDishesLeftWrapper>
                <Box sx={{ padding: '12%', display: 'flex', flexDirection: 'column', gap: '20px' }}>
                    {previewUrl ? (
                        <Box >
                            {/* Display preview of the selected image */}
                            <img
                                src={previewUrl}
                                alt="Preview"
                                style={{ maxWidth: '300px', maxHeight: '300px', borderRadius: '10px' }}
                            />
                        </Box>
                    ) : (
                        <PreviewInnerBox>
                            <Typography textAlign={'center'} sx={{ marginTop: '40%' }}>Image Preview</Typography>
                        </PreviewInnerBox>
                    )}
                    <Box textAlign={'center'}>
                        <input type="file" onChange={handleFileChange} accept="image/*" />
                    </Box>

                </Box>
           </AddDishesLeftWrapper>
           
            <AddDishesRightWrapper>
               <AddDishesForm/>
            </AddDishesRightWrapper>
        </AddDishesMainWrapper>
    );
};

export default AddDishesBox;

