import React, { useState } from 'react'
import { AddDishesRightInnerBox } from '../../assets/wrapper/AddDishesWrappper'
import { Box, Button, Switch, TextField, Typography } from '@mui/material'
import CancelIcon from '@mui/icons-material/Cancel';
import BeenhereIcon from '@mui/icons-material/Beenhere';

const AddDishesForm = () => {
    const [checked, setChecked] =useState(false);
    const [checked2, setChecked2] =useState(false);

    const handleChange = (event) => {
        setChecked(event.target.checked);
    };
    const handleChange2 = (event) => {
        setChecked2(event.target.checked);
    };
  return (
    <>
    <Box sx={{display:'flex',gap:'50px'}}>
              <AddDishesRightInnerBox>
                  <Box sx={{ display: 'grid', gap: '10px', marginBottom: '1%' }}>
                      <label htmlFor="dish-name">Dish Name</label>
                      <TextField
                          name="dishName"
                          placeholder="Enter Dish Name"
                          variant="outlined"
                          sx={{
                              width: '350px', '& .MuiOutlinedInput-root': {
                                  height: '40px', 
                                  '&:hover .MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'orange', // Change the border color on hover
                                  },
                                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'orange', // Change the border color on focus
                                  },
                              },
                          }}
                      />
                  </Box>
                  <Box sx={{ display: 'grid', gap: '10px', marginBottom: '1%' }} >
                      <label htmlFor="dish-name">Category</label>
                      <TextField
                          name="category"
                          placeholder="Enter Category"
                          variant="outlined"
                          sx={{
                              width: '350px', '& .MuiOutlinedInput-root': {
                                  height: '40px',
                                  '&:hover .MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'orange', // Change the border color on hover
                                  },
                                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'orange', // Change the border color on focus
                                  },
                              },
                          }}
                      />
                  </Box>
                  <Box sx={{ display: 'flex', gap: '10px', marginBottom: '1%' }}>
                      <Box sx={{ display: 'grid', gap: '10px' }}>
                          <label htmlFor="dish-name">Selling Price</label>
                          <TextField
                              name=''
                              placeholder="Selling Price"
                              variant="outlined"
                              sx={{
                                  width: '170px', '& .MuiOutlinedInput-root': {
                                      height: '40px', // Adjust the height of the input field
                                      '&:hover .MuiOutlinedInput-notchedOutline': {
                                          borderColor: 'orange', // Change the border color on hover
                                      },
                                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                          borderColor: 'orange', // Change the border color on focus
                                      },
                                  },
                              }}
                          />
                      </Box>
                      <Box sx={{ display: 'grid', gap: '10px' }}>
                          <label htmlFor="dish-name">Cost Price</label>
                          <TextField
                              name=''
                              placeholder="Cost Price"
                              variant="outlined"
                              sx={{
                                  width: '170px', '& .MuiOutlinedInput-root': {
                                      height: '40px', // Adjust the height of the input field
                                      '&:hover .MuiOutlinedInput-notchedOutline': {
                                          borderColor: 'orange', // Change the border color on hover
                                      },
                                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                          borderColor: 'orange', // Change the border color on focus
                                      },
                                  },
                              }}
                          />
                          
                      </Box>
                  </Box>
                  <Box sx={{ display: 'grid', gap: '10px', marginBottom: '1%' }} >
                      <label htmlFor="dish-name">Quantity</label>
                      <TextField
                          name="category"
                          placeholder="Enter Quantity"
                          variant="outlined"
                          sx={{
                              width: '350px', '& .MuiOutlinedInput-root': {
                                  height: '40px',
                                  '&:hover .MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'orange', // Change the border color on hover
                                  },
                                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'orange', // Change the border color on focus
                                  },
                              },
                          }}
                      />
                  </Box>

              </AddDishesRightInnerBox>
              <AddDishesRightInnerBox>
                 
                  <Box sx={{ display: 'grid', gap: '10px', marginBottom: '1%' }} >
                      <label htmlFor="dish-name">Description</label>
                      <TextField
                          name="category"
                          placeholder="Description..."
                          variant="outlined"
                          multiline
                          rows={4}
                          sx={{
                              width: '350px', '& .MuiOutlinedInput-root': {
                                  '&:hover .MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'orange', // Change the border color on hover
                                  },
                                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'orange', // Change the border color on focus
                                  },
                              },
                          }}
                      />
                  </Box>
                  <Box sx={{ display: 'grid', gap: '10px', marginBottom: '1%' }}>
                      <label htmlFor="dish-name">Status</label>
                      <TextField
                          name=""
                          placeholder="Upload Status"
                          variant="outlined"
                          sx={{
                              width: '350px', '& .MuiOutlinedInput-root': {
                                  height: '40px',
                                  '&:hover .MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'orange', // Change the border color on hover
                                  },
                                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                      borderColor: 'orange', // Change the border color on focus
                                  },
                              },
                          }}
                      />
                  </Box>
                  <Box sx={{ display: 'flex',flexDirection:'column', gap: '10px', margin: '2% 0% 0% 0%' }}>
                      <Box sx={{ display: 'flex', gap: '140px' }}>
                          <label htmlFor="dish-name">Discount</label>
                          <Box display={'flex'} sx={{}}>

                       <Typography sx={{marginTop:'6px'}}>Add Discount</Typography>
                          <Switch
                          color='warning'
                              checked={checked}
                              onChange={handleChange}
                              inputProps={{ 'aria-label': 'controlled' }}
                          />
                          </Box>
                      </Box>
                      <Box sx={{ display: 'flex', gap: '10px',marginLeft:'40%' }}>
                          <Button sx={{ backgroundColor:'rgb(255, 128, 128)' ,
                           '&:hover':{
                                backgroundColor:'red'
                            }}} variant="contained" startIcon={<CancelIcon />}>
                             Clear
                          </Button>
                          <Button sx={{ background:'rgb(252, 103, 54)',
                              '&:hover': {
                                  backgroundColor: 'rgb(252, 103, 54)'
                              }
                          }}variant="contained" startIcon={<BeenhereIcon/>} >
                              Save
                          </Button>
                      </Box>
                     
                  </Box>
                  

              </AddDishesRightInnerBox>
    </Box>
         
    
    </>
  )
}

export default AddDishesForm