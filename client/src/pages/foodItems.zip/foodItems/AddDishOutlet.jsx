import React from 'react'
import AddDishes from './AddDishes';

const AddDishOutlet = () => {
  return (
    <div>
     <AddDishes/>
    </div>
  )
}

export default AddDishOutlet;